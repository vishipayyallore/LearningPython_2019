import sys

print(sys.argv[0])
print(sys.argv[1:])

#for arg in sys.argv:
#    print(arg)