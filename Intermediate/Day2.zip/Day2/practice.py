"""This File is used for practice the programs daily
"""

# import subprocess


# subprocess.Popen
# pl = subprocess.Popen(['tasklist'], stdout=subprocess.PIPE).communicate()[0]
# print(pl.decode('utf-8'))

"""
from tkinter import *
from tkinter.ttk import *

win = Tk()
win.title('Lable Demo')
win.geometry("250x100")
win.configure(bg='light blue')

label = Label(win, text="Hello Python", font="Verdana 10 bold", foreground="blue")
label.pack()

button = Button(win, text="Say Hello")
button.pack()

win.mainloop()
"""


