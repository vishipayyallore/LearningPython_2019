What is Python?
History of Python
Silent Features of Python
Python Programming Domains
Why Should You Learn Python?
Compiler vs interpreter
Installing Python
Introduction to Visual Studio Code
Working with Python Interpreter 
REPL, Command line (Python)
Print() function
Pep 8 (Python Style Guide)
Pep 20 (Python Zen)


