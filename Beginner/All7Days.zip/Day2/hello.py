#!/usr/bin/env python3

import sys

print(sys.executable)
print(sys.version)
print(sys.prefix)
print(sys.path)

print("Hello World")

name = input("Enter your Name: ")

