from mathmodule import *


divide = divide_two_numbers(1, '0')
print(f'Divide: {divide}')


add = add_two_numbers(1, 2)
print(f'Addition: {add}')

add = add_two_numbers(1, 's')
print(f'Addition: {add}')


divide = divide_two_numbers(1, 0)
print(f'Divide: {divide}')

divide = divide_two_numbers(1, '0')
print(f'Divide: {divide}')
