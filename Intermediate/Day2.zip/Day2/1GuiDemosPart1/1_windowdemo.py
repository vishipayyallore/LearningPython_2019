import tkinter as tk
from tkinter import ttk

window = tk.Tk()
window.title('Window Demo')
window.geometry("300x80")
window.configure(bg='light blue')

window.mainloop()
