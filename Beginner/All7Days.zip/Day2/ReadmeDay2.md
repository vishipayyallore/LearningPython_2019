
print('*' * 10 )
Shabang

''
""
"""
''' 
string

string with Index 0 to N-1
string with Negative -1 index

slicing
[0: 3]

string.find('ddd') => returns index of first occurence. 


if( expression ):
    statements

>>> if '':
	print('No')

	
>>> if 'a':
	print('Yes')

	
Yes


while expression:
    statements

